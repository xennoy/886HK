module.exports = {
    routes: [
      // { // Path for patching one data
      //   method: 'PATCH',
      //   path: '/broken-products/:id', 
      //   handler: 'broken-product.update',
      // },

      
    ]
}