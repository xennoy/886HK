'use strict';

/**
 * label router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::label.label', {
    except: ['update'],
});
