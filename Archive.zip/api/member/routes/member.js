'use strict';

/**
 * member router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::member.member',{
    except: ['update', 'delete'],
});
