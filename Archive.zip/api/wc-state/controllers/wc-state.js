'use strict';

/**
 *  wc-state controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::wc-state.wc-state');
