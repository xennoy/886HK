'use strict';

/**
 * wc-state router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::wc-state.wc-state');
