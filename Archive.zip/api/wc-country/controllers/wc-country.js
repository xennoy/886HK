'use strict';

/**
 *  wc-country controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::wc-country.wc-country');
