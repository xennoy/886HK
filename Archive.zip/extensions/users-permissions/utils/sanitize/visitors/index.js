'use strict';

module.exports = {
  removeUserRelationFromRoleEntities: require('./remove-user-relation-from-role-entities'),
};
